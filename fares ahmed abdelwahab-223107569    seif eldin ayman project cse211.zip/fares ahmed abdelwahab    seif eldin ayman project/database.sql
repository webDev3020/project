CREATE DATABASE neogym;
USE neogym;

CREATE TABLE members (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    phone VARCHAR(20),
    join_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO members (name, email, phone) VALUES
('samy ghonim', 'samy@gmail.com', '01142414789'),
('lina osama', 'lina@example.com', '01010306737');