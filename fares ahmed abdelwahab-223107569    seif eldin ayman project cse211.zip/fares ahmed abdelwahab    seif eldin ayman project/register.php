<?php include 'db_connect.php'; ?>
<!DOCTYPE html>
<html>
<head>
    <title>Register Member</title>
</head>
<body>
    <h2>Member Registration</h2>
    <form action="process_form.php" method="POST">
        <label>Name:</label>
        <input type="text" name="name" required><br>
        <label>Email:</label>
        <input type="email" name="email" required><br>
        <label>Phone:</label>
        <input type="text" name="phone"><br>
        <input type="submit" value="Register">
    </form>
</body>
</html>