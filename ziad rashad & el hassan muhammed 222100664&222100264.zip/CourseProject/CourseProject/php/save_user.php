<?php
require 'db.php';

// Ensure the request method is POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Read the input data
    $name = $_POST['name'] ?? '';
    $email = $_POST['email'] ?? '';

    // Validate inputs
    if (empty($name) || empty($email)) {
        http_response_code(400);
        echo json_encode(['message' => 'Name and email are required.']);
        exit;
    }

    // Insert data into the database
    try {
        $stmt = $pdo->prepare("INSERT INTO users (name, email) VALUES (:name, :email)");
        $stmt->execute(['name' => $name, 'email' => $email]);
        http_response_code(201);
        echo json_encode(['message' => 'User saved successfully.']);
    } catch (PDOException $e) {
        http_response_code(500);
        echo json_encode(['message' => 'Error saving user.', 'error' => $e->getMessage()]);
    }
} else {
    http_response_code(405);
    echo json_encode(['message' => 'Invalid request method. Use POST.']);
}
?>
