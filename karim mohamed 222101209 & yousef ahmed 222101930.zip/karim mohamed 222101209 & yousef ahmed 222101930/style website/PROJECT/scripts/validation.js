document.getElementById('registrationForm').addEventListener('submit', function(event) {
  const email = document.getElementById('email').value;
  const password = document.getElementById('password').value;

  
  const emailPattern =  /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/
  if (!emailPattern.test(email)) {
    alert('Please enter a valid email address.');
    event.preventDefault(); 
    return;
  }

  
  const passwordPattern = /^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{8,}$/;
  if (!passwordPattern.test(password)) {
    alert('Password must be at least 8 characters long and include at least one number and one special character.');
    event.preventDefault(); 
  }
});
