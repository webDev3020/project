function calculateTotal() {
 
  const quantity1 = parseInt(document.getElementById("quantity1").value) || 0;
  const quantity2 = parseInt(document.getElementById("quantity2").value) || 0;
  const quantity3 = parseInt(document.getElementById("quantity3").value) || 0;
  const quantity4 = parseInt(document.getElementById("quantity4").value) || 0;

 
  const price1 = 25; 
  const price2 = 40; 
  const price3 = 30; 
  const price4 = 15; 

  
  const totalPrice = (price1 * quantity1) + (price2 * quantity2) + (price3 * quantity3) + (price4 * quantity4);

 
  document.getElementById("totalPrice").innerText = totalPrice.toFixed(2);
}

function resetCalculator() {
  
  document.getElementById("quantity1").value = 0;
  document.getElementById("quantity2").value = 0;
  document.getElementById("quantity3").value = 0;
  document.getElementById("quantity4").value = 0;

  
  document.getElementById("totalPrice").innerText = "0";
}



  