// forms.js
function showLogin() {
  document.getElementById("slider").style.left = "0";
  document.getElementById("login-form").style.left = "0";
  document.getElementById("register-form").style.left = "100%";
}

function showRegister() {
  document.getElementById("slider").style.left = "50%";
  document.getElementById("login-form").style.left = "-100%";
  document.getElementById("register-form").style.left = "0";
}

function handleLogin(event) {
  event.preventDefault();
  alert("Login successful!");
}

function handleRegister(event) {
  event.preventDefault();
  alert("Registration successful!");
}
