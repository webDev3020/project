document.addEventListener("mousemove", function(event) {
  let mouseX = event.clientX;
  let mouseY = event.clientY;

  let parallaxElements = document.querySelectorAll(".parallax");
  parallaxElements.forEach(function(element) {
      let speed = element.getAttribute("data-speed");
      let x = (mouseX * speed) / 100;
      let y = (mouseY * speed) / 100;

      element.style.transform = `translate3d(${x}px, ${y}px, 0)`;
  });
});
