**how to login to admin panal ?**
- use the (admin@gu.com) and pass (00)

**datapase neme ( airline_reservation )**
- import it in phpmyadmin  

