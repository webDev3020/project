<?php
include '../db_connect.php';

// Fetch data from all tables
$tables = ['users',  'bookings', 'feedback','contact_form'];
$data = [];
foreach ($tables as $table) {
    $result = $conn->query("SELECT * FROM $table");
    if ($result) {
        $data[$table] = $result->fetch_all(MYSQLI_ASSOC);
    }
}

// Handle form submission for adding a flight
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['flight_number'], $_POST['origin'], $_POST['destination'], $_POST['departure_date'], $_POST['departure_time'], $_POST['price'])) {
        $flight_number = $_POST['flight_number'];
        $origin = $_POST['origin'];
        $destination = $_POST['destination'];
        $departure_date = $_POST['departure_date'];
        $departure_time = $_POST['departure_time'];
        $price = $_POST['price'];

        // Insert flight into the database
        $query = "INSERT INTO flights (flight_number, origin, destination, departure_date, departure_time, price) 
                  VALUES (?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($query);
        $stmt->bind_param('sssssd', $flight_number, $origin, $destination, $departure_date, $departure_time, $price);

        if ($stmt->execute()) {
            echo "<p>Flight added successfully!</p>";
        } else {
            echo "<p>Error adding flight: " . $stmt->error . "</p>";
        }

        $stmt->close();
    }
}

// Fetch flights from the database
$query = "SELECT * FROM flights";
$flights = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 30px;
        }
        table, th, td {
            border: 1px solid #ccc;
        }
        th, td {
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #f4f4f4;
        }
        h2 {
            color: #333;
        }
    </style>
</head>
<body>
    <h1>Admin Panel</h1>
    <?php foreach ($data as $table => $rows): ?>
        <h2>Table: <?= ucfirst($table) ?></h2>
        <table>
            <thead>
                <tr>
                    <?php foreach (array_keys($rows[0] ?? []) as $column): ?>
                        <th><?= $column ?></th>
                    <?php endforeach; ?>
                </tr>
            </thead>
            <tbody>
                <?php if ($rows): ?>
                    <?php foreach ($rows as $row): ?>
                        <tr>
                            <?php foreach ($row as $value): ?>
                                <td><?= htmlspecialchars($value) ?></td>
                            <?php endforeach; ?>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr><td colspan="<?= count(array_keys($rows[0] ?? [''])) ?>">No data available</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    <?php endforeach; ?>

    <!-- Add Flight Form -->
    <section>
        <h2>Add Flight</h2>
        <form method="POST">
            <label for="flight_number">Flight Number:</label>
            <input type="text" id="flight_number" name="flight_number" required><br>

            <label for="origin">Origin:</label>
            <input type="text" id="origin" name="origin" required><br>

            <label for="destination">Destination:</label>
            <input type="text" id="destination" name="destination" required><br>

            <label for="departure_date">Departure Date:</label>
            <input type="date" id="departure_date" name="departure_date" required><br>

            <label for="departure_time">Departure Time:</label>
            <input type="time" id="departure_time" name="departure_time" required><br>

            <label for="price">Price:</label>
            <input type="number" id="price" name="price" required><br>

            <button type="submit">Add Flight</button>
        </form>
    </section>

    <!-- Manage Flights -->
    <section>
        <h2>Manage Flights</h2>
        <table>
            <thead>
                <tr>
                    <th>Flight Number</th>
                    <th>Origin</th>
                    <th>Destination</th>
                    <th>Departure Date</th>
                    <th>Departure Time</th>
                    <th>Price</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $flights->fetch_assoc()): ?>
                    <tr>
                        <td><?= htmlspecialchars($row['flight_number']) ?></td>
                        <td><?= htmlspecialchars($row['origin']) ?></td>
                        <td><?= htmlspecialchars($row['destination']) ?></td>
                        <td><?= htmlspecialchars($row['departure_date']) ?></td>
                        <td><?= htmlspecialchars($row['departure_time']) ?></td>
                        <td><?= htmlspecialchars($row['price']) ?></td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </section>
</body>
</html>
