<?php
session_start();

$response = [
    'isLoggedIn' => isset($_SESSION['user_id']),
    'userName' => isset($_SESSION['user_name']) ? htmlspecialchars($_SESSION['user_name']) : null
];

header('Content-Type: application/json');
echo json_encode($response);
?>
