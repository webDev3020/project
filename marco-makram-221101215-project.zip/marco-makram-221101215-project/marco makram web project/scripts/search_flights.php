<?php
include '../db_connect.php';

// Fetch all flights
$query = "SELECT flight_number, origin, destination, departure_date, departure_time, price FROM flights";
$result = $conn->query($query);

// Convert results to an array
$flights = $result->fetch_all(MYSQLI_ASSOC);

// Return JSON response
header('Content-Type: application/json');
echo json_encode($flights);
?>
