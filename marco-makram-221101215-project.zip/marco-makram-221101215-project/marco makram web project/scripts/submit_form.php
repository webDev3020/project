<?php
include '../db_connect.php';  

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $message = mysqli_real_escape_string($conn, $_POST['message']);

    // Prepare the SQL query to insert data
    $sql = "INSERT INTO contact_form (name, email, message) VALUES (?, ?, ?)";

    // Prepare the statement
    if ($stmt = $conn->prepare($sql)) {
        // Bind the parameters
        $stmt->bind_param("sss", $name, $email, $message); 

        // Execute the prepared statement
        if ($stmt->execute()) {
            header("Location: ../pages/thank.html");  // Redirect on success
            exit;
        } else {
            echo json_encode(["error" => "Failed to save information."]);
        }

        // Close the statement
        $stmt->close();
    } else {
        echo json_encode(["error" => "Failed to prepare statement."]);
    }
}
?>
