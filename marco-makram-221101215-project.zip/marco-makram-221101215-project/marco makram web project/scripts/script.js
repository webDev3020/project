document.addEventListener("mousemove", (e) => {
  const layers = document.querySelectorAll(".parallax-layer");
  const x = (window.innerWidth - e.pageX * 2) / 100;
  const y = (window.innerHeight - e.pageY * 2) / 100;

  layers.forEach((layer, index) => {
    const speed = index * 0.3 + 1;
    layer.style.transform = `translate(${x * speed}px, ${y * speed}px)`;
  });
});

fetch("./scripts/session_check.php")
  .then((response) => response.json())
  .then((data) => {
    if (data.isLoggedIn) {
      console.log(`User is logged in as: ${data.userName}`);
    } else {
      console.log("User is not logged in.");
    }
  })
  .catch((error) => console.error("Error:", error));

// Fetch session status and update navigation dynamically
document.addEventListener("DOMContentLoaded", () => {
  fetch("./scripts/session_check.php")
    .then((response) => response.json())
    .then((data) => {
      const authLink = document.getElementById("auth-link");
      const welcomeMessage = document.getElementById("welcome-message");

      if (data.isLoggedIn) {
        // User is logged in
        authLink.innerHTML = `<a href="./scripts/logout.php">Logout</a>`;
        welcomeMessage.textContent = `Hello, ${data.userName}! Welcome back!`;
      } else {
        // User is not logged in
        authLink.innerHTML = `<a href="../pages/login.html">Login</a>`;
      }
    })
    .catch((error) => {
      console.error("Error fetching session status:", error);
    });
});

function loginUser(event) {
  event.preventDefault();
  alert("Login successful! Redirecting to homepage...");
  window.location.href = "../index.html";
}

// Function to calculate grade (for the grade calculator)
function calculateGrade(event) {
  event.preventDefault(); // Prevent form from refreshing the page

  const assignmentsInput = document.getElementById("assignments").value;
  const quizzesInput = document.getElementById("quizzes").value;
  const examsInput = document.getElementById("exams").value;
  const projectInput = document.getElementById("project").value;

  // Convert the input values to numbers and check if they are valid
  const assignments = parseFloat(assignmentsInput);
  const quizzes = parseFloat(quizzesInput);
  const exams = parseFloat(examsInput);
  const project = parseFloat(projectInput);

  // Check if any value is missing or invalid
  if (
    isNaN(assignments) ||
    isNaN(quizzes) ||
    isNaN(exams) ||
    isNaN(project) ||
    assignmentsInput === "" ||
    quizzesInput === "" ||
    examsInput === "" ||
    projectInput === ""
  ) {
    document.getElementById("result").textContent =
      "Please enter valid scores in all fields.";
    return;
  }

  // Calculate total marks and percentage
  const totalMarks = assignments + quizzes + exams + project;
  const percentage = (totalMarks / 400) * 100; // Total is out of 400

  // Determine the grade based on percentage
  let grade;
  if (percentage >= 90) {
    grade = "A";
  } else if (percentage >= 80) {
    grade = "B";
  } else if (percentage >= 70) {
    grade = "C";
  } else if (percentage >= 60) {
    grade = "D";
  } else {
    grade = "F";
  }

  // Display result
  const resultText = `
    Total Marks: ${totalMarks.toFixed(2)}/400<br>
    Percentage: ${percentage.toFixed(2)}%<br>
    Grade: ${grade}
  `;
  document.getElementById("result").innerHTML = resultText;
}

// Attach the grade calculation to the form
document
  .getElementById("grade-calculator-form")
  .addEventListener("submit", calculateGrade);

function submitForm(event) {
  event.preventDefault(); // Prevent the default form submission

  const name = document.getElementById("name").value;
  const email = document.getElementById("email").value;
  const password = document.getElementById("password").value;
  const confirmPassword = document.getElementById("confirm-password").value;

  // Validate form inputs
  if (!name || !email || !password || !confirmPassword) {
    alert("Please fill out all fields.");
    return;
  }

  if (password !== confirmPassword) {
    alert("Passwords do not match.");
    return;
  }
  // Feedback Form Handler
  function handleFeedback(event) {
    event.preventDefault(); // Prevent form from refreshing the page

    const name = document.getElementById("name").value;
    const email = document.getElementById("email").value;
    const message = document.getElementById("message").value;

    if (!name || !email || !message) {
      document.getElementById("feedback-result").textContent =
        "Please fill in all fields.";
      return;
    }

    document.getElementById(
      "feedback-result"
    ).textContent = `Thank you, ${name}! Your feedback has been received. We'll get back to you at ${email}.`;
  }

  // Attach the feedback handler to the form
  document
    .getElementById("feedback-form")
    .addEventListener("submit", handleFeedback);
  // Simulate successful registration and redirect to the Thank You page

  window.location.href = "../pages/thank.html";
  setTimeout(() => {
    window.location.href = "../index.html";
  }, 10000); // 10 seconds delay
}

async function loadFlights() {
  try {
    const response = await fetch("../scripts/search_flights.php");
    const flights = await response.json();

    const tableBody = document.querySelector("#flights-table tbody");
    tableBody.innerHTML = ""; // Clear any existing rows

    if (flights.length === 0) {
      tableBody.innerHTML =
        "<tr><td colspan='6'>No flights available</td></tr>";
    } else {
      flights.forEach((flight) => {
        const row = `
            <tr>
              <td>${flight.flight_number}</td>
              <td>${flight.origin}</td>
              <td>${flight.destination}</td>
              <td>${flight.departure_date}</td>
              <td>${flight.departure_time}</td>
              <td>${flight.price}</td>
            </tr>
          `;
        tableBody.insertAdjacentHTML("beforeend", row);
      });
    }
  } catch (error) {
    console.error("Error fetching flight data:", error);
  }
}

// Load all flights when the page loads
window.addEventListener("DOMContentLoaded", loadFlights);
