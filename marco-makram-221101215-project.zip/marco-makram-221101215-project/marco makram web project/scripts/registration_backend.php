<?php
session_start();
include '../db_connect.php'; // Include the database connection file

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = htmlspecialchars($_POST['name']);
    $email = htmlspecialchars($_POST['email']);
    $password = htmlspecialchars($_POST['password']);
    $confirm_password = htmlspecialchars($_POST['confirm-password']);

    // Validate form inputs
    if ($password !== $confirm_password) {
        header("Location: ../pages/registration.html?error=Passwords do not match.");
        exit();
    }

    // Hash the password
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // Prepare and bind SQL query
    $stmt = $conn->prepare("INSERT INTO Users (full_name, email, password) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $name, $email, $hashed_password);

    if ($stmt->execute()) {
        // Set session variables for the logged-in user
        $_SESSION['user_id'] = $stmt->insert_id;
        $_SESSION['user_name'] = $name;

        // Redirect to the Thank You page
        header("Location: ../pages/thank.html");
        exit();
    } else {
        header("Location: ../pages/registration.html?error=Registration failed. Please try again.");
        exit();
    }

    $stmt->close();
}
?>
