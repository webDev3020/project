<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

include '../db_connect.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Handle Feedback Form Submission
    if (isset($_POST['name'], $_POST['email'], $_POST['message'])) {
        $name = htmlspecialchars($_POST['name']);
        $email = filter_var($_POST['email'], FILTER_VALIDATE_EMAIL);
        $message = htmlspecialchars($_POST['message']);

        if (!$email) {
            echo json_encode(["error" => "Invalid email address."]);
            exit;
        }

        // Insert into database
        $stmt = $conn->prepare("INSERT INTO feedback (name, email, message) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $name, $email, $message);

        if ($stmt->execute()) {
            header("Location: ../pages/thank.html");
            exit;
        } else {
            echo json_encode(["error" => "Failed to save feedback."]);
        }
        $stmt->close();
    } else {
        echo json_encode(["error" => "Invalid form submission."]);
    }
} else {
    echo json_encode(["error" => "Invalid request method."]);
}
$conn->close();
?>
