<?php
session_start();
include '../db_connect.php'; // Include the database connection file

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = htmlspecialchars($_POST['email']);
    $password = htmlspecialchars($_POST['password']);

    // Check if the user is the admin
    if ($email === 'admin@gu.com' && $password === '00') {
        // Set admin session variables
        $_SESSION['user_id'] = 'admin';
        $_SESSION['user_name'] = 'Administrator';
        // Redirect to admin dashboard
        header("Location: ../scripts/admin.php");
        exit();
    }

    // Query the database for regular users
    $stmt = $conn->prepare("SELECT user_id, password, full_name FROM Users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();

        // Verify the password
        if (password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['user_id'];
            $_SESSION['user_name'] = $user['full_name'];
            // Redirect to the main page
            header("Location: ../index.html");
            exit();
        } else {
            // Incorrect password
            header("Location: ../pages/login.html?error=Invalid email or password.");
            exit();
        }
    } else {
        // User not found
        header("Location: ../pages/login.html?error=Invalid email or password.");
        exit();
    }

    $stmt->close();
}
?>