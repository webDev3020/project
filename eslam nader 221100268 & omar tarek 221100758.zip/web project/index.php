<?php
// Start session for managing login state
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Event Planner Homepage">
    <title>Home - Event Planner</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/global.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/photo.css">
</head>
<body>
    <!-- Header Section -->
    <header>
        <div class="logo" aria-label="Event Planner logo">
            <h1>Event Planner</h1>
        </div>
        <nav>
            <ul>
                <li><a href="index.php" class="active">Home</a></li>
                <li><a href="scripts/about.php">About Us</a></li>
                <li><a href="scripts/book-event.php">Book Events</a></li>
                <li><a href="scripts/contact.php">Contact Us</a></li>
                <?php if (isset($_SESSION['user_name'])): ?>
                    <li><a href="scripts/logout.php">Logout</a></li>
                <?php else: ?>
                    <li><a href="scripts/login.php">Login</a></li>
                    <li><a href="pages/registration.html">Registration</a></li>
                <?php endif; ?>
                <li><a href="scripts/studint.php">Student Calculate</a></li>
            </ul>
        </nav>
    </header>

    <!-- Main Content Area -->
    <main class="content">
        <!-- Parallax Hero Section -->
        <section class="hero">
            <img src="photo.jpg" alt="Background Image" class="hero-background">
            <div class="hero-content">
                <h2>Your Event Starts Here</h2>
                <p>Plan and manage your events with ease and convenience</p>
                <a href="scripts/book-event.php" class="cta-btn">Book Events</a>
            </div>
        </section>

        <section class="services">
            <h2>Our Services</h2>
            <div class="service-cards">
                <div class="service-card">
                    <h3>Easy Booking</h3>
                    <p>Plan and manage your events with just a few clicks.</p>
                </div>
                <div class="service-card">
                    <h3>Affordable Prices</h3>
                    <p>Get the best deals for organizing events.</p>
                </div>
                <div class="service-card">
                    <h3>24/7 Support</h3>
                    <p>Our customer support team is available round the clock to assist you.</p>
                </div>
            </div>
        </section>
    </main>

     <!-- Right Column -->
     <aside class="right-column">
            <section class="event-tips">
                <h3>Event Planning Tips</h3>
                <ul>
                    <li>Start planning at least 3 months in advance for larger events.</li>
                    <li>Set a clear budget and stick to it.</li>
                    <li>Choose venues that match your event theme.</li>
                    <li>Use online tools to manage guest lists and RSVPs.</li>
                </ul>
            </section>

            <section class="upcoming-events">
                <h3>Upcoming Events</h3>
                <ul>
                    <li>
                        <strong>Wedding Expo</strong> - March 10, 2025<br>
                        <em>Location:</em> Grand Ballroom, City Center
                    </li>
                    <li>
                        <strong>Corporate Networking</strong> - April 5, 2025<br>
                        <em>Location:</em> Downtown Convention Hall
                    </li>
                    <li>
                        <strong>Birthday Bash Showcase</strong> - May 15, 2025<br>
                        <em>Location:</em> Skyline Terrace
                    </li>
                </ul>
            </section>
        </aside>
    </main>

    <!-- Footer Section -->
    <footer>
        <div class="footer-content">
            <p>Contact us: <a href="mailto:eslam.hassan@gu.edu.eg">eslam.hassan@gu.edu.eg</a></p>
            <p>&copy; 2024 Event Planner | All Rights Reserved.</p>
            <p><a href="scripts/about.php">About Us</a></p>
        </div>
    </footer>
</body>
</html>


    <script>
        // Mousemove Parallax Effect
        const heroBackground = document.querySelector('.hero-background');

        document.querySelector('.hero').addEventListener('mousemove', (event) => {
            const { clientX, clientY } = event;
            const { innerWidth, innerHeight } = window;

            const xOffset = ((clientX / innerWidth) - 0.5) * 30;
            const yOffset = ((clientY / innerHeight) - 0.5) * 30;

            heroBackground.style.transform = `translate(${xOffset}%, ${yOffset}%)`;
        });
    </script>
</body>
</html>


       