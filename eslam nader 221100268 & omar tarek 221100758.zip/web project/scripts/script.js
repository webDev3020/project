// Login Page Script
document.addEventListener("DOMContentLoaded", () => {
    const loginForm = document.getElementById("login-form");
  
    loginForm.addEventListener("submit", (event) => {
      event.preventDefault();
  
      const email = document.getElementById("email").value.trim();
      const password = document.getElementById("password").value.trim();
  
      if (email && password) {
        alert("Login successful!");
        window.location.href = "/index.html"; // Redirect to homepage
      } else {
        alert("Please enter both email and password.");
      }
    });
  });
  
  // Registration Page Script
  document.addEventListener("DOMContentLoaded", () => {
    const registrationForm = document.getElementById("registration-form");
  
    registrationForm.addEventListener("submit", (event) => {
      event.preventDefault();
  
      const name = document.getElementById("name").value.trim();
      const email = document.getElementById("email").value.trim();
      const password = document.getElementById("password").value.trim();
      const confirmPassword = document.getElementById("confirm-password").value.trim();
  
      if (!name || !email || !password || !confirmPassword) {
        alert("All fields are required.");
      } else if (password !== confirmPassword) {
        alert("Passwords do not match.");
      } else {
        alert("Registration successful!");
        window.location.href = "thank.html"; // Redirect to Thank You page
      }
    });
  });
  
  // Signup Page Script
  document.addEventListener("DOMContentLoaded", () => {
    const signupForm = document.getElementById("signup-form");
  
    signupForm.addEventListener("submit", (event) => {
      event.preventDefault();
  
      const name = document.getElementById("name").value.trim();
      const email = document.getElementById("email").value.trim();
      const password = document.getElementById("password").value.trim();
      const confirmPassword = document.getElementById("confirm-password").value.trim();
  
      if (!name || !email || !password || !confirmPassword) {
        alert("All fields are required.");
      } else if (password !== confirmPassword) {
        alert("Passwords do not match.");
      } else {
        alert("Signup successful!");
        window.location.href = "thank.html"; // Redirect to Thank You page
      }
    });
  });
  
  // Thank You Page Script
  document.addEventListener("DOMContentLoaded", () => {
    const thankYouMessage = document.querySelector(".thank-container p");
  
    let countdown = 5; // Countdown in seconds
    const interval = setInterval(() => {
      if (countdown > 0) {
        thankYouMessage.innerHTML = `Thank you for registering on our website. Redirecting to homepage in ${countdown} seconds...`;
        countdown--;
      } else {
        clearInterval(interval);
        window.location.href = "/index.html"; // Redirect to homepage
      }
    }, 1000);
  });

  document.addEventListener("DOMContentLoaded", () => {
    // Grade Calculator Script
    const gradeForm = document.getElementById("grade-calculator-form");
    const gradeResults = document.getElementById("grade-results");
  
    gradeForm.addEventListener("submit", (event) => {
      event.preventDefault();
  
      const assignments = parseFloat(document.getElementById("assignments").value) || 0;
      const quizzes = parseFloat(document.getElementById("quizzes").value) || 0;
      const exams = parseFloat(document.getElementById("exams").value) || 0;
      const project = parseFloat(document.getElementById("project").value) || 0;
  
      const totalMarks = assignments + quizzes + exams + project;
      const percentage = (totalMarks / 100) * 100;
      let grade;
  
      if (percentage >= 90) grade = "A+";
      else if (percentage >= 80) grade = "A";
      else if (percentage >= 70) grade = "B";
      else if (percentage >= 60) grade = "C";
      else grade = "F";
  
      gradeResults.innerHTML = `
        <p>Total Marks: ${totalMarks}/100</p>
        <p>Percentage: ${percentage.toFixed(2)}%</p>
        <p>Grade: ${grade}</p>
      `;
    });
  
    // Feedback Form Script
    const feedbackForm = document.getElementById("feedback-form");
    const feedbackResults = document.getElementById("feedback-results");
  
    feedbackForm.addEventListener("submit", (event) => {
      event.preventDefault();
  
      const name = document.getElementById("name").value.trim();
      const email = document.getElementById("email").value.trim();
      const feedback = document.getElementById("feedback").value.trim();
  
      if (!name || !email || !feedback) {
        feedbackResults.innerHTML = "<p>Please fill out all fields.</p>";
        return;
      }
  
      feedbackResults.innerHTML = `
        <p>Thank you, <strong>${name}</strong>, for your feedback!</p>
        <p>We will get back to you at <strong>${email}</strong>.</p>
      `;
      feedbackForm.reset();
    });
  });
  