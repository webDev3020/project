<?php
// Start session for managing login state
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us - Event Planner</title>
    <link rel="stylesheet" href="../css/global.css">
    <link rel="stylesheet" href="../css/about.css">
</head>
<body>
    <header>
        <div class="logo">
            <h1>Event Planner</h1>
        </div>
        <nav>
            <ul>
                <li><a href="../index.php" class="active">Home</a></li>
                <li><a href="about.php" class="active">About Us</a></li>
                <li><a href="book-event.php">Book Events</a></li>
                <li><a href="contact.php">Contact Us</a></li>
                <?php if (isset($_SESSION['user_name'])): ?>
                    <li><a href="logout.php">Logout</a></li>
                <?php else: ?>
                    <li><a href="login.php">Login</a></li>
                    <li><a href="../pages/registration.html">Registration</a></li>
                <?php endif; ?>
          
            </ul>
        </nav>
    </header>

    <section class="about-container">
        <h2>About Us</h2>
        <p>
            Welcome to the Web Design course, where creativity meets functionality. This course equips you with the essential skills needed to design visually appealing and user-friendly websites. From understanding HTML and CSS to mastering responsive design techniques, you'll gain the knowledge needed to create modern websites. Join us to start your journey in web design and bring your ideas to life online.
        </p>
    </section>

    <footer>
        <div class="footer-content">
            <p>Contact us: <a href="mailto:eslam.hassan@gu.edu.eg">eslam.hassan@gu.edu.eg</a></p>
            <p>Contact us: <a href="mailto:omar.mohamed@gu.edu.eg">omar.mohamed@gu.edu.eg</a></p>
            <p>&copy; 2024 Event Planner | All Rights Reserved.</p>
            <p><a href="about.php">About Us</a></p>
        </div>
    </footer>
</body>
</html>
