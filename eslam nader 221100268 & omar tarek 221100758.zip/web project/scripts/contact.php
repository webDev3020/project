<?php
// Start session for managing login state
session_start();

// Include the database connection file
include 'db_connect.php';

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $message = $_POST['message'];

    // Insert contact message into the database
    $stmt = $conn->prepare("INSERT INTO messages (name, email, message) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $name, $email, $message);

    if ($stmt->execute()) {
        $success_message = "Thank you! Your message has been sent.";
    } else {
        $error_message = "Sorry, there was an error sending your message. Please try again.";
    }

    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us - Event Planner</title>
    <link rel="stylesheet" href="../css/global.css">
    <link rel="stylesheet" href="../css/contact.css">
</head>
<body>
    <header>
        <div class="logo">
            <h1>Event Planner</h1>
        </div>
        <nav>
            <ul>
               <li><a href="../index.php" class="active">Home</a></li>
                <li><a href="about.php">About Us</a></li>
                <li><a href="book-event.php">Book Events</a></li>
                <li><a href="contact.php" class="active">Contact Us</a></li>
                <?php if (isset($_SESSION['user_name'])): ?>
                    <li><a href="logout.php">Logout</a></li>
                <?php else: ?>
                    <li><a href="login.php">Login</a></li>
                    <li><a href="../pages/registration.html">Registration</a></li>
                <?php endif; ?>
              
            </ul>
        </nav>
    </header>

    <section class="contact-container">
        <h2>Contact Us</h2>
        <p>If you have any questions or need assistance, please fill out the form below.</p>

        <!-- Display Success or Error Message -->
        <?php if (isset($success_message)): ?>
            <p class="success-message"><?php echo $success_message; ?></p>
        <?php elseif (isset($error_message)): ?>
            <p class="error-message"><?php echo $error_message; ?></p>
        <?php endif; ?>

        <form action="contact.php" method="POST">
            <label for="name">Your Name</label>
            <input type="text" id="name" name="name" required>

            <label for="email">Your Email</label>
            <input type="email" id="email" name="email" required>

            <label for="message">Your Message</label>
            <textarea id="message" name="message" required></textarea>

            <button type="submit">Send Message</button>
        </form>

        <section class="contact-info">
            <h3>Our Contact Information</h3>
            <p>Email: <a href="mailto:eslam.hassan@gu.edu.eg">eslam.hassan@gu.edu.eg</a></p>
            <p>email: <a href="mailto:omar.mohamed@gu.edu.eg">omar.mohamed@gu.edu.eg</a></p>
            <p>Phone: 01101251649</p>
            <p>Phone: 011557533387</p>
            <p>Website: <a href="https://www.gu.edu.eg/" target="_blank">Galala University</a></p>
            <p>Location: Attaka - Suez</p>
        </section>
    </section>

    <footer>
        <div class="footer-content">
            <p>Contact us: <a href="mailto:eslam.hassan@gu.edu.eg">eslam.hassan@gu.edu.eg</a></p>
            <p>Contact us: <a href="mailto:omar.mohamed@gu.edu.eg">omar.mohamed@gu.edu.eg</a></p>
            <p>Phone: 01101251649</p>
            <p>Phone: 011557533387</p>
            <p>&copy; 2024 Event Planner | All Rights Reserved.</p>
            <p><a href="about.php">About Us</a></p>
        </div>
    </footer>
</body>
</html>
