<?php
// Start session for managing login state
session_start();

// Include the database connection file
include 'db_connect.php';

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $event_name = $_POST['event-name'];
    $event_date = $_POST['event-date'];
    $event_location = $_POST['event-location'];
    $event_type = $_POST['event-type'];
    $attendees = $_POST['attendees'];
    $additional_notes = $_POST['additional-notes'];

    // Insert booking into the database
    $stmt = $conn->prepare("INSERT INTO events (event_name, event_date, event_location, event_type, attendees, additional_notes) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssis", $event_name, $event_date, $event_location, $event_type, $attendees, $additional_notes);

    if ($stmt->execute()) {
        $success_message = "Your event has been successfully booked!";
    } else {
        $error_message = "Failed to book the event. Please try again.";
    }

    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book an Event - Event Planner</title>
    <link rel="stylesheet" href="../css/global.css">
    <link rel="stylesheet" href="../css/book.css">
</head>
<body>
    <header>
        <div class="logo">
            <h1>Event Planner</h1>
        </div>
        <nav>
            <ul>
            <li><a href="../index.php" class="active">Home</a></li>
                <li><a href="about.php">About Us</a></li>
                <li><a href="book-event.php" class="active">Book an Event</a></li>
                <li><a href="contact.php">Contact Us</a></li>
                <?php if (isset($_SESSION['user_name'])): ?>
                    <li><a href="logout.php">Logout</a></li>
                <?php else: ?>
                    <li><a href="login.php">Login</a></li>
                    <li><a href="../pages/registration.html">Registration</a></li>
                <?php endif; ?>
               
            </ul>
        </nav>
    </header>

    <section class="event-container">
        <div class="book-event-container">
            <h2>Book Your Event</h2>

            <!-- Success or Error Message -->
            <?php if (isset($success_message)): ?>
                <p class="success-message"><?php echo $success_message; ?></p>
            <?php elseif (isset($error_message)): ?>
                <p class="error-message"><?php echo $error_message; ?></p>
            <?php endif; ?>

            <form method="POST" action="book-event.php">
                <div class="book-event-grid">
                    <div>
                        <label for="event-name">Event Name</label>
                        <input type="text" id="event-name" name="event-name" placeholder="Enter event name" required>
                    </div>
                    <div>
                        <label for="event-date">Event Date</label>
                        <input type="date" id="event-date" name="event-date" required>
                    </div>
                </div>
                <label for="event-location">Event Location</label>
                <input type="text" id="event-location" name="event-location" placeholder="Enter location" required>
        
                <label for="event-type">Event Type</label>
                <select id="event-type" name="event-type" required>
                    <option value="">Select type</option>
                    <option value="wedding">Wedding</option>
                    <option value="conference">Conference</option>
                    <option value="birthday">Birthday</option>
                </select>
        
                <label for="attendees">Number of Attendees</label>
                <input type="number" id="attendees" name="attendees" placeholder="Enter number of attendees" required>
        
                <label for="additional-notes">Additional Notes</label>
                <textarea id="additional-notes" name="additional-notes" rows="5" placeholder="Add any extra details"></textarea>
        
                <button type="submit" class="submit-btn">Submit Booking</button>
            </form>
            <p class="book-event-footer">
                For inquiries, contact us at <a href="mailto:support@eventplanner.com">eslam.hassan@gu.edu.eg</a>
            </p>
        </div>
    </section>

    <footer>
        <div class="footer-content">
            <p>Contact us: <a href="mailto:eslam.hassan@gu.edu.eg">eslam.hassan@gu.edu.eg</a></p>
            <p>Contact us: <a href="mailto:omar.mohamed@gu.edu.eg">omar.mohamed@gu.edu.eg</a></p>
            <p>Phone: 01101251649</p>
            <p>Phone: 011557533387</p>
            
            <p>&copy; 2024 Event Planner | All Rights Reserved.</p>
            <p><a href="about.php">About Us</a></p>
        </div>
    </footer>
</body>
</html>
