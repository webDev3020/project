<?php
// Start session for managing login state
session_start();

// Include the database connection file
include 'db_connect.php';

// Handle Feedback Form Submission
if ($_SERVER["REQUEST_METHOD"] == "POST" ) {
  if (isset($_POST['submit_feedback'])){
    $name = $_POST['name'];
    $email = $_POST['email'];
    $feedback = $_POST['feedback'];

    // Insert feedback into the database
    $stmt = $conn->prepare("INSERT INTO feedback (name, email, feedback) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $name, $email, $feedback);

    if ($stmt->execute()) {
        $feedback_message = "Thank you for your feedback!";
    } else {
        $feedback_error = "Failed to submit feedback. Please try again.";
    }

    $stmt->close();
  }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Student Grade Calculator and Feedback Form</title>
  <link rel="stylesheet" href="../css/global.css">
  <link rel="stylesheet" href="../css/studint.css">
</head>
<body>
    <header>
        <div class="logo">
            <h1>Student Calculator</h1>
        </div>
        <nav>
            <ul>
                <li><a href="http://localhost/web%20project/index.php">Home</a></li>
                <?php if (isset($_SESSION['user_name'])): ?>
                    <li><a href="logout.php">Logout</a></li>
                <?php else: ?>
                    <li><a href="login.php">Login</a></li>
                    <li><a href="../pages/registration.html">Registration</a></li>
                <?php endif; ?>
            </ul>
        </nav>
    </header>

  <main>
    <!-- Grade Calculator Form -->
    <section>
      <h2>Student Grade Calculator</h2>
      <form id="grade-calculator-form" onsubmit="return calculateGrade(event)">
        <div class="input-group">
          <label for="assignments">Assignments (out of 10)</label>
          <input type="number" id="assignments" name="assignments" placeholder="Enter assignment score" required>
        </div>
        <div class="input-group">
          <label for="quizzes">Quizzes (out of 10)</label>
          <input type="number" id="quizzes" name="quizzes" placeholder="Enter quiz score" required>
        </div>
        <div class="input-group">
          <label for="exams">Exams (out of 50)</label>
          <input type="number" id="exams" name="exams" placeholder="Enter exam score" required>
        </div>
        <div class="input-group">
            <label for="project">Projects (out of 30)</label>
            <input type="number" id="project" name="project" placeholder="Enter project score" required>
          </div>
        <button type="submit" class="btn-submit">Calculate Grade</button>
      </form>
      <div id="grade-results"></div>
    </section>

    <!-- Feedback Form -->
    <section>
      <h2>Feedback Form</h2>
      <!-- Feedback Result Messages -->
      <?php if (isset($feedback_message)): ?>
          <p class="success-message"><?php echo $feedback_message; ?></p>
      <?php elseif (isset($feedback_error)): ?>
          <p class="error-message"><?php echo $feedback_error; ?></p>
      <?php endif; ?>

      <form method="POST">
        <div class="input-group">
          <label for="name">Your Name</label>
          <input type="text" id="name" name="name" required placeholder="Enter your name">
        </div>
        <div class="input-group">
          <label for="email">Your Email</label>
          <input type="email" id="email" name="email" required placeholder="Enter your email">
        </div>
        <div class="input-group">
          <label for="feedback">Your Feedback</label>
          <textarea id="feedback" name="feedback" rows="4" placeholder="Write your feedback here" required></textarea>
        </div>
        <button type="submit" name="submit_feedback" class="btn-submit">Submit Feedback</button>
      </form>
      <div id="feedback-results"></div>
    </section>
  </main>

  <footer>
      <div class="footer-content">
          <p>Contact us: <a href="mailto:eslam.hassan@gu.edu.eg">eslam.hassan@gu.edu.eg</a></p>
          <p>&copy; 2025 Event Planner | All Rights Reserved.</p>
      </div>
  </footer>

  <script>
      function calculateGrade(event) {
          event.preventDefault();
          const assignments = parseFloat(document.getElementById('assignments').value) || 0;
          const quizzes = parseFloat(document.getElementById('quizzes').value) || 0;
          const exams = parseFloat(document.getElementById('exams').value) || 0;
          const project = parseFloat(document.getElementById('project').value) || 0;

          const total = assignments + quizzes + exams + project;
          let grade;

          if (total >= 90) {
              grade = "A";
          } else if (total >= 80) {
              grade = "B";
          } else if (total >= 70) {
              grade = "C";
          } else if (total >= 60) {
              grade = "D";
          } else {
              grade = "F";
          }

          document.getElementById('grade-results').innerHTML = `
              <h3>Your Total Score: ${total}/100</h3>
              <h4>Your Grade: ${grade}</h4>
          `;
      }
  </script>
</body>
</html>
