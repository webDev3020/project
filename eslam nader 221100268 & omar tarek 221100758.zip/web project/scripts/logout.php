<?php
session_start();
session_unset();
session_destroy();
header("Location: /web%20project/index.php");
exit();
?>
