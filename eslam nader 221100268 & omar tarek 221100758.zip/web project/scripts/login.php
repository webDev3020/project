<?php
// Start session for storing error messages
session_start();

// Include the database connection file
include 'db_connect.php';

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Check if the user is the admin
    if ($email === 'admin@gu.com' && $password === '00') {
        // Redirect to the admin dashboard
        header("Location: /web%20project/admin/admin.php");
        exit();
    }

    // Query the database for the user
    $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();

        // Verify the password
        if (password_verify($password, $user['password'])) {
            // Login successful
            $_SESSION['user_name'] = $user['name'];

            // Redirect to index.html
            header("Location: /web%20project/index.php");
            exit();
        } else {
            // Incorrect password
            $_SESSION['error_message'] = "Invalid password. Please try again.";
        }
    } else {
        // User not found
        $_SESSION['error_message'] = "No account found with this email. Please register.";
    }
    header("Location: login.php"); // Redirect back to the login page
    exit();
}
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Event Planner</title>
    <link rel="stylesheet" href="../css/global.css">
    <link rel="stylesheet" href="../css/login.css">
</head>
<body>

    <!-- Header Section -->
    <header>
        <div class="logo">
            <h1>Event Planner</h1>
        </div>
        <nav>
            <ul>
                <li><a href="http://localhost/web%20project/index.php">Home</a></li>
                <li><a href="about.php">About Us</a></li>
                <li><a href="book-event.php">Book Events</a></li>
                <li><a href="contact.php">Contact Us</a></li>
                <li><a href="login.php" class="active">Login</a></li>
                <li><a href="../pages/registration.html">Registration</a></li>
            </ul>
        </nav>
    </header>

    <!-- Login Form Section -->
    <section class="login-section">
        <div class="login-container">
            <h2>Login to Your Account</h2>
            
            <!-- Display error message -->
            <?php
            if (isset($_SESSION['error_message'])) {
                echo "<p class='error-message'>" . $_SESSION['error_message'] . "</p>";
                unset($_SESSION['error_message']); // Clear the message
            }
            ?>
            
            <form id="login-form" action="login.php" method="POST">
                <div class="input-group">
                    <label for="email">Email Address</label>
                    <input type="email" id="email" name="email" required placeholder="Enter your email">
                </div>
                <div class="input-group">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" required placeholder="Enter your password">
                </div>
                <button type="submit" class="btn-submit">Login</button>
            </form>
            <p>Don't have an account? <a href="registration.html">Sign Up here</a></p>
        </div>
    </section>

    <!-- Footer Section -->
    <footer>
        <div class="footer-content">
            <p>Contact us: <a href="mailto:eslam.hassan@gu.edu.eg">eslam.hassan@gu.edu.eg</a></p>
            <p>&copy; 2024 Event Planner | All Rights Reserved.</p>
            <p><a href="about.html">About Us</a></p>
        </div>
    </footer>
</body>
</html>
