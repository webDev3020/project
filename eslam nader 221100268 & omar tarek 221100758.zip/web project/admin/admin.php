<?php
// Include database connection
include_once "../scripts/db_connect.php";

// admin_events_page.php

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['add_event'])) {
        $event_name = $_POST['event_name'];
        $event_date = $_POST['event_date'];
        $event_location = $_POST['event_location'];
        $event_type = $_POST['event_type'];
        $attendees = $_POST['attendees'];
        $additional_notes = $_POST['additional_notes'];

        $sql = "INSERT INTO events (event_name, event_date, event_location, event_type, attendees, additional_notes, created_at)
                VALUES (?, ?, ?, ?, ?, ?, NOW())";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssssds", $event_name, $event_date, $event_location, $event_type, $attendees, $additional_notes);
        $stmt->execute();
    }

    if (isset($_POST['update_event'])) {
        $id = $_POST['id'];
        $event_name = $_POST['event_name'];
        $event_date = $_POST['event_date'];
        $event_location = $_POST['event_location'];
        $event_type = $_POST['event_type'];
        $attendees = $_POST['attendees'];
        $additional_notes = $_POST['additional_notes'];

        $sql = "UPDATE events SET event_name=?, event_date=?, event_location=?, event_type=?, attendees=?, additional_notes=? WHERE id=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssssdsi", $event_name, $event_date, $event_location, $event_type, $attendees, $additional_notes, $id);
        $stmt->execute();
    }

    if (isset($_POST['delete_event'])) {
        $id = $_POST['id'];
        $sql = "DELETE FROM events WHERE id=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $id);
        $stmt->execute();
    }

    if (isset($_POST['logout'])) {
        // Logout logic
        header("Location: ../index.php");
        exit;
    }
}

// Fetch all events
$sql_events = "SELECT * FROM events ORDER BY event_date ASC";
$result_events = $conn->query($sql_events);

// Fetch all users
$sql_users = "SELECT * FROM users ORDER BY created_at ASC";
$result_users = $conn->query($sql_users);

// Fetch all feedback
$sql_feedback = "SELECT * FROM feedback ORDER BY created_at ASC";
$result_feedback = $conn->query($sql_feedback);

// Fetch all messages
$sql_messages = "SELECT * FROM messages ORDER BY created_at ASC";
$result_messages = $conn->query($sql_messages);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/global.css">
    <link rel="stylesheet" href="../css/book.css">
    <title>Admin - Manage Data</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }
        table, th, td {
            border: 1px solid black;
        }
        th, td {
            padding: 10px;
            text-align: left;
        }
        form {
            margin: 20px 0;
        }
    </style>
</head>
<body>
    <h1>Admin - Dashboard</h1>

    <form method="POST">
        <button type="submit" name="logout">Logout</button>
    </form>

    <h2>All Events</h2>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Date</th>
                <th>Location</th>
                <th>Type</th>
                <th>Attendees</th>
                <th>Notes</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $result_events->fetch_assoc()): ?>
                <tr>
                    <td><?= $row['id'] ?></td>
                    <td><?= $row['event_name'] ?></td>
                    <td><?= $row['event_date'] ?></td>
                    <td><?= $row['event_location'] ?></td>
                    <td><?= $row['event_type'] ?></td>
                    <td><?= $row['attendees'] ?></td>
                    <td><?= $row['additional_notes'] ?></td>
                    <td>
                        <form method="POST" style="display:inline-block;">
                            <input type="hidden" name="id" value="<?= $row['id'] ?>">
                            <button type="submit" name="delete_event">Delete</button>
                        </form>
                        <form method="POST" style="display:inline-block;">
                            <input type="hidden" name="id" value="<?= $row['id'] ?>">
                            <input type="text" name="event_name" value="<?= $row['event_name'] ?>" required>
                            <input type="date" name="event_date" value="<?= $row['event_date'] ?>" required>
                            <input type="text" name="event_location" value="<?= $row['event_location'] ?>" required>
                            <select name="event_type" required>
                                <option value="wedding" <?= $row['event_type'] == 'wedding' ? 'selected' : '' ?>>Wedding</option>
                                <option value="conference" <?= $row['event_type'] == 'conference' ? 'selected' : '' ?>>Conference</option>
                                <option value="birthday" <?= $row['event_type'] == 'birthday' ? 'selected' : '' ?>>Birthday</option>
                            </select>
                            <input type="number" name="attendees" value="<?= $row['attendees'] ?>" required>
                            <textarea name="additional_notes"><?= $row['additional_notes'] ?></textarea>
                            <button type="submit" name="update_event">Update</button>
                        </form>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>

    <h2>All Users</h2>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Created At</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $result_users->fetch_assoc()): ?>
                <tr>
                    <td><?= $row['id'] ?></td>
                    <td><?= $row['name'] ?></td>
                    <td><?= $row['email'] ?></td>
                    <td><?= $row['created_at'] ?></td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>

    <h2>All Messages</h2>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Message</th>
                <th>Created At</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $result_messages->fetch_assoc()): ?>
                <tr>
                    <td><?= $row['id'] ?></td>
                    <td><?= $row['name'] ?></td>
                    <td><?= $row['email'] ?></td>
                    <td><?= $row['message'] ?></td>
                    <td><?= $row['created_at'] ?></td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>

    <h2>All Feedback</h2>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>NAME</th>
                <th>Feedback</th>
                <th>Created At</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $result_feedback->fetch_assoc()): ?>
                <tr>
                    <td><?= $row['id'] ?></td>
                    <td><?= $row['name'] ?></td>
                    <td><?= $row['feedback'] ?></td>
                    <td><?= $row['created_at'] ?></td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</body>
</html>

<?php
$conn->close();
?>
