// parallax.js

document.addEventListener("scroll", () => {
  const parallaxBg = document.getElementById("parallax-bg");
  const scrollPosition = window.scrollY;

  // Adjust the background position based on scroll
  parallaxBg.style.transform = `translateY(${scrollPosition * 0.5}px)`;
});
