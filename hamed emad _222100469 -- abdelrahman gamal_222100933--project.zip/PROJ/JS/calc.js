document
  .getElementById("gradeForm")
  .addEventListener("submit", function (event) {
    event.preventDefault();

    // Get input values
    const name = document.getElementById("name").value;
    const subject = document.getElementById("subject").value;
    const grade = parseInt(document.getElementById("grade").value);

    // Determine grade category
    let category;
    if (grade >= 90) {
      category = "A";
    } else if (grade >= 80) {
      category = "B";
    } else if (grade >= 70) {
      category = "C";
    } else if (grade >= 60) {
      category = "D";
    } else {
      category = "F";
    }

    // Display result
    const result = `Student: ${name}<br>Subject: ${subject}<br>Grade: ${grade} (${category})`;
    document.getElementById("result").innerHTML = result;
  });
