<?php
// Database connection details
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "car_dealership";

// Connect to the database
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle GET request
if ($_SERVER["REQUEST_METHOD"] == "GET") {
    if (isset($_GET['username'])) {
        $name = htmlspecialchars($_GET['username']);
        echo "<h1>Welcome, $name</h1>";
    } else {
        echo "<h1>Welcome, Guest</h1>";
    }
}

// Handle form submission (POST)
$message = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $gender = $_POST['gender'];
    $dob = $_POST['dob'];

    // Basic validation
    if (!empty($name) && !empty($email) && !empty($password)) {
        // Insert data into the database
        $stmt = $conn->prepare("INSERT INTO users (name, email, password, gender, dob) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("sssss", $name, $email, $password, $gender, $dob);

        if ($stmt->execute()) {
            $message = "<p class='success'>Thank you, $name. Your registration was successful!</p>";
        } else {
            $message = "<p class='error'>Error: " . $stmt->error . "</p>";
        }

        $stmt->close();
    } else {
        $message = "<p class='error'>Please fill in all required fields.</p>";
    }
}

// Fetch all registered users
$sql = "SELECT name, email, gender, dob FROM users";
$result = $conn->query($sql);

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../styles/reg.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <title>BoxCars | Registration</title>
</head>
<body>
<header>
    <nav class="navbar">
        <ul>
            <i class="fa-solid fa-car fa-2xl"></i>
            <li><a href="compare.html">Compare</a></li>
            <li><a href="../index.html">Home</a></li>
            <li><a href="about.html">About Us</a></li>
            <li><a href="contact.html">Contact Me</a></li>
            <li><a href="https://www.gu.edu.eg" target="_blank">GU Website</a></li>
        </ul>
    </nav>
</header>
<main>
    <section class="registration-form">
        <h2>Register Here</h2>
        <!-- Display success/error message -->
        <div id="message"><?php if (!empty($message)) echo $message; ?></div>
        <form action="registration.php" method="post">
            <!-- Full Name -->
            <label for="name">Full Name:</label>
            <input type="text" id="name" name="name" placeholder="Enter your full name" required>

            <!-- Email -->
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" placeholder="Enter your email" required>

            <!-- Password -->
            <label for="password">Password:</label>
            <input type="password" id="password" name="password" placeholder="Enter your password" required>

            <!-- Gender -->
            <label for="gender">Gender:</label>
            <select id="gender" name="gender">
                <option value="" disabled selected>Select Gender</option>
                <option value="male">Male</option>
                <option value="female">Female</option>
                <option value="other">Other</option>
            </select>

            <!-- Date of Birth -->
            <label for="dob">Date of Birth:</label>
            <input type="date" id="dob" name="dob">

            <!-- Submit Button -->
            <button type="submit">Register</button>
        </form>
    </section>

    <section class="registered-users">
        <h2>Registered Users</h2>
        <table>
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Gender</th>
                    <th>Date of Birth</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . htmlspecialchars($row['name']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['email']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['gender']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['dob']) . "</td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='4'>No registered users found.</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </section>
</main>
</body>
</html>
