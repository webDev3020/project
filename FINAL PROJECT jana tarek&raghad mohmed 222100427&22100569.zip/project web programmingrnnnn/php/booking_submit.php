<?php
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    // Handle preflight request for CORS
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    include 'db_connect.php';

    $location = trim($_POST['location']);
    $date = trim($_POST['date']);
    $type = trim($_POST['type']);

    if (empty($location) || empty($date) || empty($type)) {
        die('Error: All fields are required.');
    }

    // Database query to save booking
    $query = "INSERT INTO bookings (location, date, type) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('sss', $location, $date, $type);

    if ($stmt->execute()) {
        echo 'Booking successful!';
    } else {
        echo 'Error: Could not save booking. Please try again.';
    }

    $stmt->close();
    $conn->close();
} else {
    die('Invalid request.');
}
?>
