<?php
include 'db_connect.php';

$results = $db->query("SELECT * FROM bookings");

echo "<h1>Bookings</h1>";
while ($row = $results->fetchArray()) {
    echo "<p>{$row['location']} - {$row['date']} - {$row['type']}</p>";
}
?>
