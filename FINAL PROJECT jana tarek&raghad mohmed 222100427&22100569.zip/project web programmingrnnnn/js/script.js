document.addEventListener('DOMContentLoaded', () => {
    // Parallax effect mouse move 
    document.addEventListener('mousemove', (event) => {
        const elements = document.querySelectorAll('.parallax img, .parallax .text-overlay');
        const mouseX = event.clientX;
        const mouseY = event.clientY;
        const windowWidth = window.innerWidth;
        const windowHeight = window.innerHeight;

        elements.forEach((element) => {
            const speedX = parseFloat(element.getAttribute('data-speed-x')) || 1;
            const speedY = parseFloat(element.getAttribute('data-speed-y')) || 1;
            const shiftX = ((mouseX - windowWidth / 2) / windowWidth) * speedX * 10;
            const shiftY = ((mouseY - windowHeight / 2) / windowHeight) * speedY * 10;

            element.style.transform = `translate(${shiftX}px, ${shiftY}px)`;
        });
    });

    // Parallax scroll effect
    let lastScrollPosition = 0;
    let ticking = false;
    document.addEventListener('scroll', () => {
        lastScrollPosition = window.pageYOffset;
        if (!ticking) {
            window.requestAnimationFrame(() => {
                const parallax = document.querySelector('.parallax img');
                const textOverlay = document.querySelector('.text-overlay');

                if (parallax) parallax.style.transform = `translateY(${lastScrollPosition * 0.5}px)`;
                if (textOverlay) textOverlay.style.transform = `translateY(${lastScrollPosition * 0.3}px)`;

                ticking = false;
            });
            ticking = true;
        }
    });

    // Toggle form register/login
    window.toggleForm = (formType) => {
        const loginForm = document.getElementById('login-form');
        const registerForm = document.getElementById('register-form');
        const loginButton = document.querySelector('.tab-button:first-child');
        const registerButton = document.querySelector('.tab-button:last-child');

        if (formType === 'login') {
            loginForm.classList.add('active');
            registerForm.classList.remove('active');
            loginButton.classList.add('active');
            registerButton.classList.remove('active');
        } else {
            loginForm.classList.remove('active');
            registerForm.classList.add('active');
            loginButton.classList.remove('active');
            registerButton.classList.add('active');
        }
    };

    // Handle form submissions
    document.getElementById('login-form')?.addEventListener('submit', function(event) {
        event.preventDefault();
        alert('Logged in successfully!');
    });

    document.getElementById('register-form')?.addEventListener('submit', function(event) {
        event.preventDefault();
        alert('Registered successfully!');
    });

    // Grade calculator 
    const calculateButton = document.getElementById('calculateButton');
    const inputs = document.querySelectorAll('#gradeForm input[type="number"]');
    inputs.forEach(input => {
        input.addEventListener('input', () => {
            const min = parseFloat(input.min) || 0;
            const max = parseFloat(input.max) || 100;
            if (parseFloat(input.value) < min) input.value = min;
            if (parseFloat(input.value) > max) input.value = max;
        });
    });

    calculateButton?.addEventListener('click', () => {
        const quiz = Math.max(0, Math.min(15, parseFloat(document.getElementById('quiz').value) || 0));
        const assignment = Math.max(0, Math.min(20, parseFloat(document.getElementById('assignment').value) || 0));
        const exam = Math.max(0, Math.min(10, parseFloat(document.getElementById('exam').value) || 0));
        const project = Math.max(0, Math.min(15, parseFloat(document.getElementById('project').value) || 0));
        const finalExam = Math.max(0, Math.min(40, parseFloat(document.getElementById('final').value) || 0));

        if (
            quiz < 0 || quiz > 15 ||
            assignment < 0 || assignment > 20 ||
            exam < 0 || exam > 10 ||
            project < 0 || project > 15 ||
            finalExam < 0 || finalExam > 40
        ) {
            document.getElementById('result').innerHTML = `<span style="color:red;">Please enter valid grades within the allowed ranges.</span>`;
            return;
        }

        const totalMarks = quiz + assignment + exam + project + finalExam;
        const percentage = (totalMarks / 100) * 100;
        const grade =
            percentage >= 90 ? 'A' :
            percentage >= 80 ? 'B' :
            percentage >= 70 ? 'C' :
            percentage >= 60 ? 'D' : 'F';

        document.getElementById('result').innerHTML = `
            <strong>Results:</strong><br>
            Total Marks: ${totalMarks}/100<br>
            Percentage: ${percentage.toFixed(2)}%<br>
            Grade: <span style="color: #31c2cc;">${grade}</span>
        `;
    });
});

