// Dynamic year update for footer copyright
document.querySelector('.footerbottom').innerHTML = `Copyright &copy; ${new Date().getFullYear()} Designed by <span class="designer">Jana Elbadry</span>`;

// Social media hover effect
document.querySelectorAll('.socializations a').forEach(icon => {
    icon.addEventListener('mouseover', () => {
        icon.classList.add('highlight');
    });
    icon.addEventListener('mouseout', () => {
        icon.classList.remove('highlight');
    });
});
  // Parallax Effect for Image
  const parallaxImage = document.querySelector('.page-two-image-container img');

  window.addEventListener('scroll', function () {
      let scrollPosition = window.scrollY;
      parallaxImage.style.transform = `translateY(${scrollPosition * 0.8}px)`;
  });
  console.log(parallaxImage);
