document.addEventListener("DOMContentLoaded", () => {
    // Highlight
    const carModelSelect = document.getElementById("car-model");
    const pricingTable = document.getElementById("pricing-table");

    carModelSelect.addEventListener("change", () => {
        const selectedModel = carModelSelect.value;
        const rows = pricingTable.querySelectorAll("tr");

        rows.forEach((row, index) => {
            if (index === 0) return; // Skip header row
            const cellText = row.cells[0].textContent.toLowerCase();
            if (cellText === selectedModel) {
                row.style.border = "2px solid #31C2CC";
                row.style.transition = "border-color 0.3s ease";
            } else {
                row.style.border = "1px solid #ccc";
            }
        });
    });

    // Date Selection Validation 
    const pickupDateInput = document.getElementById('pickup-date');
    const dropoffDateInput = document.getElementById('dropoff-date');
    const checkAvailabilityButton = document.querySelector('.btn'); 

    // Set min date for pickup and dropoff dates
    const today = new Date().toISOString().split('T')[0]; 
    pickupDateInput.setAttribute('min', today);
    dropoffDateInput.setAttribute('min', today);

    checkAvailabilityButton.addEventListener('click', (event) => {
        const pickupDate = new Date(pickupDateInput.value);
        const dropoffDate = new Date(dropoffDateInput.value);

        // Check if dates are valid
        if (!pickupDateInput.value || !dropoffDateInput.value) {
            alert('Please select both pick-up and drop-off dates.');
            event.preventDefault(); 
            return;
        }

        // Check if drop-off date is before pick-up date
        if (dropoffDate < pickupDate) {
            alert('Drop-off date cannot be earlier than the pick-up date. Please select valid dates.');
            event.preventDefault(); 
        }
    });
});
