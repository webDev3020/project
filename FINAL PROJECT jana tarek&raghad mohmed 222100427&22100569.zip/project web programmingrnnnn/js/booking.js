// Form validation for booking button
document.addEventListener("DOMContentLoaded", function() {
    const bookNowBtn = document.querySelector('.book-now-btn');
    const destinationInput = document.querySelector('.search-input');
    const dateInput = document.querySelector('#date');

    bookNowBtn.addEventListener('click', function(event) {
        // Validate fields before submission
        if (destinationInput.value.trim() === '') {
            alert('Please enter a destination.');
            event.preventDefault(); 
            return;
        }

        if (dateInput.value === '') {
            alert('Please select booking dates.');
            event.preventDefault();
        }
    });
});


// Destination suggestions
document.addEventListener("DOMContentLoaded", function() {
    const destinationInput = document.querySelector('.search-input');
    const searchContainer = document.querySelector('.search-container');

    const destinations = [
        "Amsterdam", "Athens", "Bangkok", "Barcelona", "Berlin", "Budapest",
        "Cairo", "Cape Town", "Dubai", "Dublin", "Florence", "Hong Kong",
        "Istanbul", "Jakarta", "Kuala Lumpur", "Lisbon", "London",
        "Los Angeles", "Madrid", "Milan", "Moscow", "Mexico City",
        "New York", "Palermo", "Paris", "Prague", "Rome", "Seoul",
        "Stockholm", "Sydney", "Tokyo", "Toronto", "Venice", "Vienna",
        "Warsaw", "Zurich"
    ];

    const suggestionBox = document.createElement('div');
    suggestionBox.classList.add('suggestion-box');
    document.body.appendChild(suggestionBox);

    function positionSuggestionBox() {
        const rect = destinationInput.getBoundingClientRect();
        suggestionBox.style.width = `${rect.width}px`;
        suggestionBox.style.left = `${rect.left}px`;
        suggestionBox.style.top = `${rect.bottom + window.scrollY}px`;
    }

    function populateSuggestions(filter = '') {
        suggestionBox.innerHTML = '';
        const filteredDestinations = destinations.filter(dest =>
            dest.toLowerCase().includes(filter.toLowerCase())
        );

        if (filteredDestinations.length === 0) {
            suggestionBox.innerHTML = '<div class="suggestion-item">No Results Found</div>';
        } else {
            filteredDestinations.sort().forEach(dest => {
                const suggestionItem = document.createElement('div');
                suggestionItem.textContent = dest;
                suggestionItem.classList.add('suggestion-item');
                suggestionItem.addEventListener('click', function() {
                    destinationInput.value = dest;
                    suggestionBox.innerHTML = '';
                });
                suggestionBox.appendChild(suggestionItem);
            });
        }
        positionSuggestionBox();
    }

    destinationInput.addEventListener('focus', function() {
        populateSuggestions();
    });

    destinationInput.addEventListener('input', function() {
        populateSuggestions(destinationInput.value);
    });

    document.addEventListener('click', function(e) {
        if (!searchContainer.contains(e.target)) {
            suggestionBox.innerHTML = '';
        }
    });

    window.addEventListener('resize', positionSuggestionBox);
});

// Single Date Range Picker
document.addEventListener("DOMContentLoaded", function() {
    const dateRangeInput = document.querySelector('#date');

    flatpickr(dateRangeInput, {
        mode: "range",
        dateFormat: "Y-m-d",
        minDate: "today",
        onChange: function(selectedDates, dateStr) {
            console.log("Selected Dates: ", dateStr);
        }
    });
});



