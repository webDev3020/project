document.querySelector('.contact-form form').onsubmit = function(event) {
    // Get form elements
    const name = document.getElementById('name');
    const email = document.getElementById('email');
    const message = document.getElementById('message');
    
    // email validation
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    let errors = [];

    // Check if name is filled
    if (name.value.trim() === '') {
        errors.push('Please enter your name.');
    }

    // Validate email
    if (email.value.trim() === '') {
        errors.push('Please enter your email.');
    } else if (!emailPattern.test(email.value)) {
        errors.push('Please enter a valid email address.');
    }

    // Check if message is filled
    if (message.value.trim() === '') {
        errors.push('Please enter a message.');
    }

    // If there are errors
    if (errors.length > 0) {
        alert(errors.join('\n'));
        event.preventDefault();  
    } else {
        alert('Form submitted successfully!');
    }
};
//remaning charcahters
document.addEventListener('DOMContentLoaded', function () {
    const messageBox = document.getElementById('message');
    const counter = document.getElementById('char-counter');
    const maxChars = 300;

    messageBox.addEventListener('input', function () {
        const remaining = maxChars - messageBox.value.length;

        // Enforce the character limit by trimming excess
        if (remaining < 0) {
            messageBox.value = messageBox.value.substring(0, maxChars);
        }

        // Update the counter text
        const currentLength = messageBox.value.length;
        counter.textContent = `${maxChars - currentLength} characters remaining`;

        // Change counter color 
        counter.style.color = remaining < 0 ? 'red' : '';
    });
});
