document.addEventListener('DOMContentLoaded', () => {
    const countryCards = document.querySelectorAll('.country-card');

    const fadeInOnScroll = () => {
        countryCards.forEach((card) => {
            const rect = card.getBoundingClientRect();
            if (rect.top < window.innerHeight && rect.bottom > 0) {
                card.classList.add('visible');
            } else {
                card.classList.remove('visible');
            }
        });
    };

    document.addEventListener('scroll', fadeInOnScroll);
    fadeInOnScroll(); 

    // Tooltip for country names
    const tooltips = document.querySelectorAll('.country-card h2');
    tooltips.forEach((tooltip) => {
        tooltip.addEventListener('mouseenter', (event) => {
            const text = event.target.textContent;
            const tooltipDiv = document.createElement('div');
            tooltipDiv.className = 'tooltip';
            tooltipDiv.textContent = `Explore ${text}`;
            document.body.appendChild(tooltipDiv);

            const rect = event.target.getBoundingClientRect();
            tooltipDiv.style.left = `${rect.left + rect.width / 2 - tooltipDiv.offsetWidth / 2}px`;
            tooltipDiv.style.top = `${rect.top - tooltipDiv.offsetHeight - 10}px`;
        });

        tooltip.addEventListener('mouseleave', () => {
            const tooltipDiv = document.querySelector('.tooltip');
            if (tooltipDiv) tooltipDiv.remove();
        });
    });

    // Hover effect for images (zoom-in)
    const images = document.querySelectorAll('.country-card img');
    images.forEach((img) => {
        img.addEventListener('mouseenter', () => {
            img.style.transform = 'scale(1.1)';
        });

        img.addEventListener('mouseleave', () => {
            img.style.transform = 'scale(1)';
        });
    });
});
