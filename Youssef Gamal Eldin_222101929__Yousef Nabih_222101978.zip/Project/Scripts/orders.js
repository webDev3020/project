/*
    ID & Name: Youssef Gamal ElDin 222101929
    ID & Name: Yousef Nabih 222101978
    Course: CSE211 Web Programming
    Assignment: Course Project
    Date: 2025-01-16 
    Description: javascript for orders page.
*/

document.addEventListener('DOMContentLoaded', function() {
    const filterForm = document.getElementById('filter-orders-form');
    const patientSelect = document.getElementById('patient');
    const drugSelect = document.getElementById('drug-id');
    const clearFiltersButton = document.getElementById('clear-filters'); 
    const ordersTable = document.getElementById('orders-table').getElementsByTagName('tbody')[0];

    const orders = [
        { orderId: 1001, patient: 'Alice Brown', drug: 'Paracetamol', quantity: 30, orderDate: '2024-01-01' },
        { orderId: 1002, patient: 'Bob Knight', drug: 'Ibuprofen', quantity: 20, orderDate: '2024-01-03' },
        { orderId: 1003, patient: 'Alice Brown', drug: 'Amoxicillin', quantity: 50, orderDate: '2024-01-05' },
        { orderId: 1004, patient: 'Bob Knight', drug: 'Paracetamol', quantity: 10, orderDate: '2024-01-07' }
    ];

    function renderOrders(filteredOrders) {
        ordersTable.innerHTML = '';

        filteredOrders.forEach(order => {
            const row = ordersTable.insertRow();
            row.innerHTML = `
                <td>${order.orderId}</td>
                <td>${order.patient}</td>
                <td>${order.drug}</td>
                <td>${order.quantity}</td>
                <td>${order.orderDate}</td>
            `;
        });
    }

    filterForm.addEventListener('submit', function(event) {
        event.preventDefault();

        const selectedPatient = patientSelect.value;
        const selectedDrug = drugSelect.value;

        const filteredOrders = orders.filter(order => {
            const matchesPatient = !selectedPatient || order.patient === patientSelect.options[patientSelect.selectedIndex].text.split(' - ')[1];
            const matchesDrug = !selectedDrug || order.drug === drugSelect.options[drugSelect.selectedIndex].text.split(' - ')[1];

            return matchesPatient && matchesDrug;
        });

        renderOrders(filteredOrders);
    });

   
    clearFiltersButton.addEventListener('click', function() {
       
        patientSelect.value = '';
        drugSelect.value = '';
        renderOrders(orders);
    });

    renderOrders(orders); 
});
