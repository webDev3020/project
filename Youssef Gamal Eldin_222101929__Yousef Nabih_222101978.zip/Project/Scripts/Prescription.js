/*
    ID & Name: Youssef Gamal ElDin 222101929
    ID & Name: Yousef Nabih 222101978
    Course: CSE211 Web Programming
    Assignment: Course Project
    Date: 2025-01-16 
    Description: javascript for prescription page.
*/

document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('add-drug-btn').addEventListener('click', function() {
        const drugSelect = document.getElementById('choose-drug');
        const drugDose = document.getElementById('drug-dose').value;
        const selectedDrug = drugSelect.options[drugSelect.selectedIndex].text;

        if (drugDose.trim() !== '') {
            const drugItem = document.createElement('li');
            drugItem.textContent = `${selectedDrug} - Dose: ${drugDose}`;

            const deleteButton = document.createElement('button');
            deleteButton.textContent = 'Delete';
            deleteButton.addEventListener('click', function() {
                drugItem.remove();
                updatePrescriptionSummary();
            });

            drugItem.appendChild(deleteButton);
            document.getElementById('drugs-display-box').appendChild(drugItem);

            updatePrescriptionSummary();
        } else {
            alert('Please enter a dose for the selected drug.');
        }
    });

    document.getElementById('add-diagnosis-btn').addEventListener('click', function() {
        const diagnosisSelect = document.getElementById('choose-diagnosis');
        const selectedDiagnosis = diagnosisSelect.options[diagnosisSelect.selectedIndex].text;

        const diagnosisItem = document.createElement('li');
        diagnosisItem.textContent = selectedDiagnosis;

        const deleteButton = document.createElement('button');
        deleteButton.textContent = 'Delete';
        deleteButton.addEventListener('click', function() {
            diagnosisItem.remove();
            updatePrescriptionSummary();
        });

        diagnosisItem.appendChild(deleteButton);
        document.getElementById('diagnoses-display-box').appendChild(diagnosisItem);

        updatePrescriptionSummary();
    });

    document.getElementById('delete-btn').addEventListener('click', function() {
        document.getElementById('selected-patient').textContent = 'None';
        document.getElementById('selected-drugs-summary').textContent = 'None';
        document.getElementById('selected-diagnoses-summary').textContent = 'None';
        
        alert('Prescription summary has been cleared.');
    });

    document.getElementById('prescription-form').addEventListener('submit', function(event) {
        event.preventDefault();
        
        const drugs = document.getElementById('drugs-display-box').children;
        const diagnoses = document.getElementById('diagnoses-display-box').children;

        if (drugs.length === 0 || diagnoses.length === 0) {
            alert('Please add at least one drug and one diagnosis before submitting.');
        } else {
            alert('Prescription submitted successfully!');
        }
    });

    function updatePrescriptionSummary() {
        const patientSelect = document.getElementById('patient');
        const selectedPatient = patientSelect.options[patientSelect.selectedIndex].text;
        const drugs = document.getElementById('drugs-display-box').children;
        const diagnoses = document.getElementById('diagnoses-display-box').children;

        document.getElementById('selected-patient').textContent = selectedPatient;

        const drugList = [];
        for (let i = 0; i < drugs.length; i++) {
            drugList.push(drugs[i].textContent.replace('Delete', '').trim());
        }
        document.getElementById('selected-drugs-summary').textContent = drugList.join(', ') || 'None';

        const diagnosisList = [];
        for (let i = 0; i < diagnoses.length; i++) {
            diagnosisList.push(diagnoses[i].textContent.replace('Delete', '').trim());
        }
        document.getElementById('selected-diagnoses-summary').textContent = diagnosisList.join(', ') || 'None';
    }
});
