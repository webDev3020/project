/*
    ID & Name: Youssef Gamal ElDin 222101929
    ID & Name: Yousef Nabih 222101978
    Course: CSE211 Web Programming
    Assignment: Course Project
    Date: 2025-01-16 
    Description: JavaScript for grade calculator.
*/

function calculateGrade() {
    const assignments = parseFloat(document.getElementById("assignments").value);
    const quizzes = parseFloat(document.getElementById("quizzes").value);
    const projects = parseFloat(document.getElementById("projects").value);
    const exams = parseFloat(document.getElementById("exams").value);

    // Validate inputs
    if (
        isNaN(assignments) || isNaN(quizzes) || 
        isNaN(projects) || isNaN(exams) ||
        assignments < 0 || assignments > 20 ||
        quizzes < 0 || quizzes > 10 ||
        projects < 0 || projects > 30 ||
        exams < 0 || exams > 40
    ) {
        document.getElementById("result").textContent = 
            "Please enter valid scores within the specified ranges.";
        return;
    }

    const totalScore = assignments + quizzes + projects + exams;

    let letterGrade;
    if (totalScore >= 97) {
        letterGrade = "A+";
    } else if (totalScore >= 93) {
        letterGrade = "A";
    } else if (totalScore >= 90) {
        letterGrade = "A-";
    } else if (totalScore >= 87) {
        letterGrade = "B+";
    } else if (totalScore >= 83) {
        letterGrade = "B";
    } else if (totalScore >= 80) {
        letterGrade = "B-";
    } else if (totalScore >= 77) {
        letterGrade = "C+";
    } else if (totalScore >= 73) {
        letterGrade = "C";
    } else if (totalScore >= 70) {
        letterGrade = "C-";
    } else if (totalScore >= 67) {
        letterGrade = "D+";
    } else if (totalScore >= 63) {
        letterGrade = "D";
    } else if (totalScore >= 60) {
        letterGrade = "D-";
    } else {
        letterGrade = "F";
    }

    document.getElementById("result").textContent = 
        `Total Score: ${totalScore}/100 (${totalScore.toFixed(2)}%). Grade: ${letterGrade}`;
}