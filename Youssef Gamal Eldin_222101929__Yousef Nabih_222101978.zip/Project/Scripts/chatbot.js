/*
    ID & Name: Youssef Gamal ElDin 222101929
    ID & Name: Yousef Nabih 222101978
    Course: CSE211 Web Programming
    Assignment: Course Project
    Date: 2025-01-16 
    Description: javascript for chatbot.
*/

function restrictHostInput(event) {
    const allowedPattern = /^[a-zA-Z]*$/;
    let inputChar = String.fromCharCode(event.keyCode);
    if (!allowedPattern.test(inputChar) && event.key !== 'Backspace') {
        event.preventDefault();
    }
}

function restrictPortInput(event) {
    const allowedPattern = /^[0-9]*$/;
    let inputChar = String.fromCharCode(event.keyCode);
    if (!allowedPattern.test(inputChar) && event.key !== 'Backspace') {
        event.preventDefault();
    }
}

function restrictUserInput(event) {
    const allowedPattern = /^[a-zA-Z0-9]*$/;
    let inputChar = String.fromCharCode(event.keyCode);
    if (!allowedPattern.test(inputChar) && event.key !== 'Backspace') {
        event.preventDefault();
    }
}

function restrictPasswordInput(event) {
    const allowedPattern = /^[a-zA-Z0-9!@#$%^&*()_+]*$/;
    let inputChar = String.fromCharCode(event.keyCode);
    if (!allowedPattern.test(inputChar) && event.key !== 'Backspace') {
        event.preventDefault();
    }
}

function restrictMessageInput(event) {
    const allowedPattern = /^[a-zA-Z0-9\s]*$/;
    let inputChar = String.fromCharCode(event.keyCode);
    if (!allowedPattern.test(inputChar) && event.key !== 'Backspace') {
        event.preventDefault();
    }
}