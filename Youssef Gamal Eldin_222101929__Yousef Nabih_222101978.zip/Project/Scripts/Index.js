/*
    ID & Name: Youssef Gamal ElDin 222101929
    ID & Name: Yousef Nabih 222101978
    Course: CSE211 Web Programming
    Assignment: Course Project
    Date: 2025-01-16 
    Description: javascript for homepage.
*/

window.onload = function () {
    console.log("JavaScript is running!");

    const isLoggedIn = sessionStorage.getItem('isLoggedIn') === 'true';
    const userRole = sessionStorage.getItem('role');

    updateNavigationVisibility(isLoggedIn, userRole);

    document.getElementById('doctor-login-form')?.addEventListener('submit', function (event) {
        event.preventDefault();
        console.log("Doctor login form submitted");

        const doctorId = document.getElementById('doctor-id')?.value;
        const doctorPassword = document.getElementById('doctor-password')?.value;

        if (doctorId && doctorPassword) {
            sessionStorage.setItem('isLoggedIn', 'true');
            sessionStorage.setItem('role', 'doctor');
            alert(`Welcome, Doctor ${doctorId}!`);
            updateNavigationVisibility(true, 'doctor');
            window.location.href = "pages/inventory.html";
        } else {
            alert('Please enter both Doctor ID and Password.');
        }
    });

    document.getElementById('user-login-form')?.addEventListener('submit', function (event) {
        event.preventDefault();
        console.log("User login form submitted");

        const userEmail = document.getElementById('user-email')?.value;
        const userPassword = document.getElementById('user-password')?.value;

        if (userEmail && userPassword) {
            sessionStorage.setItem('isLoggedIn', 'true');
            sessionStorage.setItem('role', 'user');
            alert(`Welcome, ${userEmail}!`);
            updateNavigationVisibility(true, 'user');
            window.location.href = "Pages/Placeanorder.html";
        } else {
            alert('Please enter both Email and Password.');
        }
    });

    document.getElementById('user-registration-form')?.addEventListener('submit', function (event) {
        event.preventDefault();
        console.log("User registration form submitted");

        const registerName = document.getElementById('register-name')?.value;

        if (registerName) {
            alert(`Registration successful! Thank you for signing up, ${registerName}`);
            sessionStorage.setItem('isLoggedIn', 'true');
            sessionStorage.setItem('role', 'user');
            updateNavigationVisibility(true, 'user');
            window.location.href = "Pages/thankYou.html";
        } else {
            alert('Please enter your name to register.');
        }
    });

    document.getElementById('logout-button')?.addEventListener('click', function () {
        sessionStorage.removeItem('isLoggedIn');
        sessionStorage.removeItem('role');
        updateNavigationVisibility(false, null);
        alert('You have been logged out.');
        window.location.href = 'index.html';
    });
};

function updateNavigationVisibility(isLoggedIn, userRole) {
    const restrictedLinks = document.querySelectorAll('.restricted');
    const placeOrderLink = document.getElementById('place-order-link');

    if (isLoggedIn) {
        console.log("User is logged in");
        if (userRole === 'doctor') {
            restrictedLinks.forEach(link => link.style.display = 'block');
            if (placeOrderLink) placeOrderLink.style.display = 'none';
        } else if (userRole === 'user') {
            restrictedLinks.forEach(link => link.style.display = 'none');
            if (placeOrderLink) placeOrderLink.style.display = 'block';
        }
    } else {
        console.log("User is not logged in");
        restrictedLinks.forEach(link => link.style.display = 'none');
        if (placeOrderLink) placeOrderLink.style.display = 'none';
    }
}

function showDoctorLogin() {
    document.getElementById('doctor-login-section').style.display = 'block';
    document.getElementById('user-login-section').style.display = 'none';
}

function showUserLogin() {
    document.getElementById('user-login-section').style.display = 'block';
    document.getElementById('doctor-login-section').style.display = 'none';
}