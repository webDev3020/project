/*
    ID & Name: Youssef Gamal ElDin 222101929
    ID & Name: Yousef Nabih 222101978
    Course: CSE211 Web Programming
    Assignment: Course Project
    Date: 2025-01-16 
    Description: javascript for inventory.
*/

function editMedicine(rowId) {
    document.getElementById(`name${rowId}`).readOnly = false;
    document.getElementById(`quantity${rowId}`).readOnly = false;
    document.getElementById(`dose${rowId}`).readOnly = false;
    document.getElementById(`saveBtn${rowId}`).classList.remove('hidden');
}

function saveMedicine(rowId) {
    document.getElementById(`name${rowId}`).readOnly = true;
    document.getElementById(`quantity${rowId}`).readOnly = true;
    document.getElementById(`dose${rowId}`).readOnly = true;
    document.getElementById(`saveBtn${rowId}`).classList.add('hidden');
    alert('Changes saved!');
}

function deleteMedicine(rowId) {
    const row = document.getElementById(`row${rowId}`);
    row.remove();
}

function addNewMedicine() {
    const table = document.getElementById('inventoryTable').querySelector('tbody');
    const rowId = table.rows.length + 1;
    const newRow = `
        <tr id="row${rowId}">
            <td>${rowId}</td>
            <td><input type="text" id="name${rowId}" value="New Medicine" readonly></td>
            <td><input type="number" id="quantity${rowId}" value="0" readonly></td>
            <td><input type="text" id="dose${rowId}" value="0 mg" readonly></td>
            <td>
                <button type="button" onclick="editMedicine(${rowId})">Edit</button>
                <button type="button" onclick="deleteMedicine(${rowId})">Delete</button>
                <button type="button" id="saveBtn${rowId}" class="hidden" onclick="saveMedicine(${rowId})">Save</button>
            </td>
        </tr>`;
    table.insertAdjacentHTML('beforeend', newRow);
}