/*
    ID & Name: Youssef Gamal ElDin 222101929
    ID & Name: Yousef Nabih 222101978
    Course: CSE211 Web Programming
    Assignment: Course Project
    Date: 2025-01-16 
    Description: JavaScript for place order page.
*/

document.getElementById('submit-details-button').addEventListener('click', function () {
    const name = document.getElementById('name').value;
    const address = document.getElementById('address').value;
    const contact = document.getElementById('contact').value;

    // Regex pattern for valid Egyptian phone numbers
    const phonePattern = /^01[0-2,5][0-9]{8}$/;

    // Validate phone number
    if (!phonePattern.test(contact)) {
        displayMessage("Please enter a valid 11-digit Egyptian phone number.", "error-message");
        return;
    }

    // Validate all inputs
    if (name && address && contact) {
        const summary = `Name: ${name}\nAddress: ${address}\nContact: ${contact}`;
        document.getElementById('order-summary').value = summary;
        displayMessage("Details submitted successfully.", "success-message");
    } else {
        displayMessage("Please fill out all details before submitting.", "error-message");
    }
});

document.querySelectorAll(".medicine-checkbox").forEach((checkbox) => {
    checkbox.addEventListener("change", (event) => {
        const row = event.target.closest("tr");
        const quantityInput = row.querySelector(".quantity-input");
        quantityInput.disabled = !event.target.checked; // Disable quantity input if checkbox is unchecked
        if (!event.target.checked) {
            quantityInput.value = ""; // Clear quantity if unchecked
        }
    });
});

document.getElementById("add-order-button").addEventListener("click", () => {
    const medicines = [];
    const checkboxes = document.querySelectorAll(".medicine-checkbox");

    checkboxes.forEach((checkbox) => {
        if (checkbox.checked) {
            const row = checkbox.closest("tr");
            const medicineName = row.cells[1].textContent.trim(); // Medicine name
            const price = parseFloat(row.cells[2].textContent.replace("$", "").trim()); // Price
            const quantity = parseInt(row.querySelector(".quantity-input").value || "0", 10); // Quantity

            if (quantity > 0) {
                medicines.push({
                    name: medicineName,
                    price: price,
                    quantity: quantity,
                    total: price * quantity,
                });
            }
        }
    });

    if (medicines.length > 0) {
        let summary = document.getElementById('order-summary').value + "\n\nOrder Details:\n";
        let grandTotal = 0;

        medicines.forEach((medicine) => {
            summary += `- ${medicine.name}: $${medicine.price.toFixed(2)} x ${medicine.quantity} = $${medicine.total.toFixed(2)}\n`;
            grandTotal += medicine.total;
        });

        summary += `\nGrand Total: $${grandTotal.toFixed(2)}`;
        document.getElementById('order-summary').value = summary;
        displayMessage("Order added to summary.", "success-message");
    } else {
        displayMessage("No medicines selected or quantities entered.", "error-message");
    }
});

function displayMessage(message, messageType) {
    const messageBox = document.getElementById('confirmation-message');
    messageBox.textContent = message;
    messageBox.className = messageType; 
    messageBox.style.display = "block"; 
}