function calculateGrade() {
    // Initialize variables and store user input
    const assignmentsInput = document.getElementById('assignments').value;
    const quizzesInput = document.getElementById('quizzes').value;
    const examsInput = document.getElementById('exams').value;
    const projectInput = document.getElementById('project').value;

    // Convert inputs to float
    const assignments = parseFloat(assignmentsInput);
    const quizzes = parseFloat(quizzesInput);
    const exams = parseFloat(examsInput);
    const project = parseFloat(projectInput);

    // Check for empty inputs
    if (isNaN(assignments) || isNaN(quizzes) || isNaN(exams) || isNaN(project)) {
        document.getElementById('result').innerText = 'Please fill in all the fields with valid numbers.';
        return;
    }

    // Perform calculations
    const totalMarks = assignments + quizzes + exams + project;
    const percentage = ((totalMarks / 100) * 100).toFixed(2);

    // Assign grade based on percentage
    let grade;
    if (percentage >= 90) {
        grade = 'A';
    } else if (percentage >= 80) {
        grade = 'B';
    } else if (percentage >= 70) {
        grade = 'C';
    } else if (percentage >= 60) {
        grade = 'D';
    } else {
        grade = 'F';
    }

    // Display results
    document.getElementById('result').innerText = `Total Marks: ${totalMarks}\nPercentage: ${percentage}%\nGrade: ${grade}`;
}
// login & sign up section
const loginTab = document.getElementById("login-tab");
const registerTab = document.getElementById("register-tab");
const formContent = document.getElementById("form-content");

loginTab.addEventListener("click", () => {
    formContent.style.transform = "translateX(0)";
    loginTab.classList.add("active");
    registerTab.classList.remove("active");
});

registerTab.addEventListener("click", () => {
    formContent.style.transform = "translateX(-50%)";
    registerTab.classList.add("active");
    loginTab.classList.remove("active");
});
//responsive sliding login
function makeresposiveform() {
    const formwrapper = document.getElementById("form-wrapper");
    const width = window.innerWidth;
    if (width < 400) {
        formwrapper.style.flexDirection = "column";
        formContent.style.width = "100%";
    } else {
        formwrapper.style.flexDirection = "row";
        formContent.style.width = "50%";

    }
}
window.addEventListener("resize", makeresposiveform);
makeresposiveform();
//Mousemove parallax
function parallax(event) {
    const parallaxElement = document.querySelectorAll(".parallax-img");
    parallaxElement.forEach((Element) => {

        const speed = Element.getAttribute("data-speed");
        const x = (window.innerHeight - event.pageX * speed) / 100;
        const y = (window.innerWidth - event.pageY * speed) / 100;
        Element.style.transform = "transateX(${x}px) translateY(${y}px)";
    });
}
document.addEventListener("mousemove", parallax);
//ES6 classes
class loginform {
    constructor() {
        this.loginTab = document.getElementById("login-tab");
        this.registerTab = document.getElementById("register-tab");
        this.formContent = document.getElementById("form-content");
        this.initlisteners();
    }
    initlisteners() {
        this.loginTab.addEventListener("click", () => this.switchtologin());
        this.registerTab.addEventListener("click", () => this.switchtoregister());
    }
    switchtologin() {
        this.formContent.style.transform = "translateX(0)";
        this.loginTab.classList.add("active");
        this.registerTab.classList.remove("active");
    }
    switchtoregister() {
        this.formContent.style.transform = "translateX(-60%)";
        this.registerTab.classList.add("active");
        this.loginTab.classList.remove("active");
    }
}
class calculateGrade {
    constructor() {
        this.resultelement = document.getElementById("result");
        this.initlisteners();
    }
    initlisteners() {
        document.getElementById("calculateGrade").addEventListener("click", () => this.calculateGrade());
    }
    initlisteners() {
        document.getElementById("calculateGrade").addEventListener("click", () => this.calculateGrade());
    }
    calculateGrade() {
        const assignments = parseFloat(document.getElementById("assignments").value);
        const quizzes = parseFloat(document.getElementById("quizzes").value);
        const exams = parseFloat(document.getElementById("exams").value);
        const project = parseFloat(document.getElementById("project").value);
        if (isNaN(quizzes) || isNaN(exams) || isNaN(assignments) || isNaN(project)) {
            this.resultelement.innerText = "please fill this field with correct number ";
            return;
        }
        const totalMarks = assignments + quizzes + exams + project;
        const percentage = ((totalMarks / 400) * 100).toFixed(2);
        let grade;
        if (percentage >= 90) grade = "A";
        else if (percentage >= 80) grade = "B";
        else if (percentage >= 70) grade = "C";
        else if (percentage >= 60) grade = "D";
        else grade = "F";
        this.resultelement.innerText = "total Mraks : ${totalmarks}\npercentage:${percantage}%\ngrade:${grade}";
    }
}
//intiallize classes
const formManager = new loginform();
const calculateGrade = new calculateGrade();