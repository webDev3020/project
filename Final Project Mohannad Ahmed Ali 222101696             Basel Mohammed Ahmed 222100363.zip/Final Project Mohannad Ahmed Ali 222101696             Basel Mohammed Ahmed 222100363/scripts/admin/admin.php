<?php
// Include database connection
include '../../config.php';

// Handle form submission to add products
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['addProduct'])) {
    $productName = mysqli_real_escape_string($conn, $_POST['productName']);
    $category = mysqli_real_escape_string($conn, $_POST['category']);
    $price = floatval($_POST['price']);
    $quantity = intval($_POST['quantity']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);

    // Handle product image upload
    $imagePath = "images/default-product.png"; // Default image
    if (!empty($_FILES['productImage']['name'])) {
        $targetDir = "images/";
        $targetFile = $targetDir . basename($_FILES['productImage']['name']);
        $imageFileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));

        // Validate file type and size
        $allowedTypes = ['jpg', 'jpeg', 'png', 'gif'];
        if (in_array($imageFileType, $allowedTypes) && $_FILES['productImage']['size'] <= 5000000) { // 5MB max
            if (move_uploaded_file($_FILES['productImage']['tmp_name'], $targetFile)) {
                $imagePath = $targetFile;
            } else {
                $message = "Error uploading file.";
            }
        } else {
            $message = "Invalid file type or file too large.";
        }
    }

    // Insert product into the database
    $query = "INSERT INTO Products (ProductName, Category, Price, Quantity, Description, ImagePath)
              VALUES ('$productName', '$category', $price, $quantity, '$description', '$imagePath')";

    if (mysqli_query($conn, $query)) {
        $message = "Product added successfully!";
    } else {
        $message = "Error: " . mysqli_error($conn);
    }
}

// Fetch all products from the database
$productQuery = "SELECT * FROM Products";
$result = mysqli_query($conn, $productQuery);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Electromart</title>
    <link rel="stylesheet" href="css/global.css">
    <link rel="stylesheet" href="css/admin.css">
</head>

<body>
    <header>
        <h1>Admin Dashboard</h1>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="admin_dashboard.php">Dashboard</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <!-- Display message for product addition -->
        <?php if (!empty($message)) : ?>
            <p style="color: green;">
                <?= $message ?>
            </p>
        <?php endif; ?>

        <h2>Add a New Product</h2>
        <form action="admin_dashboard.php" method="POST" enctype="multipart/form-data">
            <label for="productName">Product Name:</label>
            <input type="text" id="productName" name="productName" required><br><br>

            <label for="category">Category:</label>
            <input type="text" id="category" name="category" required><br><br>

            <label for="price">Price:</label>
            <input type="number" id="price" name="price" step="0.01" required><br><br>

            <label for="quantity">Quantity:</label>
            <input type="number" id="quantity" name="quantity" required><br><br>

            <label for="description">Description:</label><br>
            <textarea id="description" name="description" rows="5" cols="40" required></textarea><br><br>

            <label for="productImage">Product Image:</label>
            <input type="file" id="productImage" name="productImage" accept="image/*"><br><br>

            <button type="submit" name="addProduct">Add Product</button>
        </form>

        <hr>

        <h2>Available Products</h2>
        <div class="product-list">
            <?php if (mysqli_num_rows($result) > 0) : ?>
                <?php while ($product = mysqli_fetch_assoc($result)) : ?>
                    <div class="product-item">
                        <img src="<?= $product['ImagePath'] ?? 'images/default-product.png' ?>" alt="<?= $product['ProductName'] ?>" width="150">
                        <h3><?= htmlspecialchars($product['ProductName']) ?></h3>
                        <p>Category: <?= htmlspecialchars($product['Category']) ?></p>
                        <p>Price: $<?= number_format($product['Price'], 2) ?></p>
                        <p>Quantity: <?= htmlspecialchars($product['Quantity']) ?></p>
                        <p>Description: <?= htmlspecialchars($product['Description']) ?></p>
                    </div>
                <?php endwhile; ?>
            <?php else : ?>
                <p>No products available.</p>
            <?php endif; ?>
        </div>
    </main>

    <footer>
        <p>&copy; 2024 Electromart - Admin Dashboard</p>
    </footer>
</body>

</html>
