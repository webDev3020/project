<?php
$servername = "localhost";
$username = "basel";
$password = "test1234";
$dbname = "electromart";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
