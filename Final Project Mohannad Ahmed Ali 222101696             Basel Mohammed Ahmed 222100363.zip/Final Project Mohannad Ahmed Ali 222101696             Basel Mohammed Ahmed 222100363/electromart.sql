-- Create the database
CREATE DATABASE ElectroMart;

-- Use the database
USE ElectroMart;

-- Create the Users table
CREATE TABLE Users (
    UserID INT AUTO_INCREMENT PRIMARY KEY,
    Username VARCHAR(50) NOT NULL UNIQUE,
    Email VARCHAR(100) NOT NULL UNIQUE,
    PasswordHash VARCHAR(255) NOT NULL, -- Add this column for storing password hashes
    Role ENUM('admin', 'user') NOT NULL DEFAULT 'user',
    CreatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create the Products table
CREATE TABLE Products (
    ProductID INT AUTO_INCREMENT PRIMARY KEY,
    ProductName VARCHAR(100) NOT NULL,
    Category VARCHAR(50),
    Price DECIMAL(10, 2) NOT NULL,
    Quantity INT DEFAULT 0,
    Description TEXT,
    AddedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert data into Products table
INSERT INTO Products (ProductName, Category, Price, Quantity, Description)
VALUES 
('iPhone 14', 'Smartphone', 999.99, 10, 'Latest Apple smartphone with A16 chip'),
('AirPods Pro', 'Accessories', 249.99, 50, 'Noise-cancelling wireless earbuds'),
('Apple Watch', 'Wearables', 399.99, 30, 'Smartwatch with fitness tracking features'),
('Xiaomi Mi 11', 'Smartphone', 699.99, 15, 'Flagship phone from Xiaomi with AMOLED display'),
('Realme Watch', 'Wearables', 49.99, 20, 'Affordable smartwatch with heart rate monitoring');
