<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Electromart - Home</title>
    <link rel="stylesheet" href="css/global.css">
    <link rel="stylesheet" href="css/style.css">
    
</head>

<body>
    <!-- Header -->
    <header>
        <h1>Electromart</h1>
        <marquee>Welcome to Electromart! Latest products, offers, and updates here!</marquee>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="pages/about.html">About Us</a></li>
                <li><a href="pages/contact.html">Contact</a></li>
                <li><a href="scripts/login.php">Login</a></li>
                <li><a href="pages/grade.html">Grade Calculator</a></li>
            </ul>
            <form>
                <input type="search" placeholder="Search here...">
                <button type="submit">Search</button>
            </form>
        </nav>
    </header>

    <!-- Main Content -->
    <main>
        <h2>Welcome to Electromart</h2>
        <p>Your one-stop destination for all electronic gadgets.</p>

        <!-- Features List -->
        <h3>Our Features</h3>
        <ul>
            <li>Free Shipping</li>
            <li>24/7 Customer Support</li>
        </ul>
        <ol>
            <li>Wide range of products</li>
            <li>Exclusive discounts</li>
        </ol>

        <!-- Electronics Section -->
        <h3>Electronics</h3>
        <p>Gadgets like smartphones, laptops, and accessories.</p>

        <!-- Products Section -->
        <h3>Top Products</h3>
        <div id="demos">
            <div class="container">
                <div class="row">
                    <div id="demo-container">
                    <?php
                        // Include database connection
                        include 'config.php';

                        // Query to fetch products
                        $query = "SELECT * FROM Products LIMIT 5"; // Fetch only 5 products
                        $result = mysqli_query($conn, $query);

                        if (mysqli_num_rows($result) > 0) {
                            // Define an array of image paths for the 5 products
                            $imagePaths = [
                                'images/iphone.png',
                                'images/airpods.png',
                                'images/apple.png',
                                'images/xiaomi.png',
                                'images/realmi watch.png',
                            ];

                            $index = 0; // Index to track the current product image

                            // Loop through products and display them
                            while ($row = mysqli_fetch_assoc($result)) {
                                // Use the corresponding image path from the array
                                $imageURL = $imagePaths[$index];

                                echo '<div class="mix home">';
                                echo '<a href="#">';
                                echo '<div class="parallax" data-speed="5">';
                                echo '<img class="parallax-img" src="' . htmlspecialchars($imageURL) . '" alt="' . htmlspecialchars($row['ProductName']) . '" />';
                                echo '</div>';
                                echo '<h3>' . htmlspecialchars($row['ProductName']) . '</h3>';
                                echo '<p>Category: ' . htmlspecialchars($row['Category']) . '</p>';
                                echo '<p>Price: $' . number_format($row['Price'], 2) . '</p>';
                                echo '<p>' . htmlspecialchars($row['Description']) . '</p>';
                                echo '</a>';
                                echo '</div>';

                                $index++; // Move to the next image
                            }
                        } else {
                            echo '<p>No products available.</p>';
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- Calculator -->
        <h3>Simple Calculator</h3>
        <form name="calc">
            <input type="text" name="display" readonly>
            <br>
            <input type="button" value="1" onclick="calc.display.value += '1'">
            <input type="button" value="2" onclick="calc.display.value += '2'">
            <input type="button" value="3" onclick="calc.display.value += '3'">
            <input type="button" value="+" onclick="calc.display.value += '+'">
            <br>
            <input type="button" value="0" onclick="calc.display.value += '0'">
            <input type="button" value="=" onclick="calc.display.value = eval(calc.display.value)">
            <input type="button" value="C" onclick="calc.display.value = ''">
        </form>
        <a href="https://www.gu.edu.eg/">Galala University</a>
    </main>

    <!-- Footer -->
    <footer>
        <p>&copy; 2024 Electromart | <a href="mailto:info@electromart.com">Contact Us</a></p>
        <p>Follow us: <a href="#">Facebook</a> | <a href="#">Twitter</a> | <a href="#">Instagram</a></p>
    </footer>

    <script src="scripts/grade.js"></script>
</body>

</html>

<?php
// Close the database connection at the very end
mysqli_close($conn);
?>